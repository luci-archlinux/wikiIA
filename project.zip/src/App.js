import React, { useState, useEffect } from 'react';
import WikiSearchBar from './components/WikiSearchBar';
import WikiResultItem from './components/WikiResultItem';
import WikiHistory from './components/WikiHistory';

const App = () => {
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [searchHistory, setSearchHistory] = useState([]);

  const searchWikipedia = async (query) => {
    if (!query.trim()) return;
    
    setLoading(true);
    setError(null);
    
    try {
      // Actualizar historial
      const newHistory = [...new Set([query, ...searchHistory])].slice(0, 5);
      setSearchHistory(newHistory);
      localStorage.setItem('wikiSearchHistory', JSON.stringify(newHistory));
      
      // Hacer búsqueda
      const response = await fetch(
        `https://es.wikipedia.org/w/api.php?action=query&list=search&srsearch=${encodeURIComponent(query)}&format=json&origin=*&utf8=1&srlimit=5`
      );
      const data = await response.json();
      setResults(data.query?.search || []);
    } catch (err) {
      setError('Error al buscar en Wikipedia. Intenta de nuevo.');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    // Cargar historial guardado
    const savedHistory = JSON.parse(localStorage.getItem('wikiSearchHistory')) || [];
    setSearchHistory(savedHistory);
  }, []);

  return (
    <div className="min-h-screen bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold text-center text-gray-900 mb-2">WikiIA</h1>
        <p className="text-center text-gray-600 mb-8">Tu buscador inteligente de Wikipedia</p>
        
        <WikiSearchBar onSearch={searchWikipedia} />
        
        {loading && (
          <div className="mt-8 text-center">
            <div className="inline-block animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-blue-500"></div>
          </div>
        )}
        
        {error && (
          <div className="mt-8 p-4 bg-red-50 text-red-700 rounded-lg">
            {error}
          </div>
        )}
        
        <div className="mt-8 space-y-4">
          {results.map((result) => (
            <WikiResultItem 
              key={result.pageid}
              title={result.title}
              snippet={result.snippet}
              pageid={result.pageid}
            />
          ))}
        </div>
        
        {searchHistory.length > 0 && (
          <WikiHistory 
            history={searchHistory} 
            onSelect={searchWikipedia} 
          />
        )}
      </div>
    </div>
  );
};

export default App;

// DONE