const WikiResultItem = ({ title, snippet, pageid }) => {
  return (
    <div className="p-6 mb-4 bg-white rounded-xl shadow-sm hover:shadow-md transition-shadow">
      <h3 className="text-xl font-semibold text-blue-600 mb-2">{title}</h3>
      <div 
        className="prose prose-sm max-w-none text-gray-700"
        dangerouslySetInnerHTML={{ __html: snippet }}
      />
      <a 
        href={`https://es.wikipedia.org/?curid=${pageid}`} 
        target="_blank" 
        rel="noopener noreferrer"
        className="mt-3 inline-block text-blue-500 hover:text-blue-700 font-medium"
      >
        Leer más →
      </a>
    </div>
  );
};

export default WikiResultItem;