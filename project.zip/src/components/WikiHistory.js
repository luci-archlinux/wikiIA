const WikiHistory = ({ history, onSelect }) => {
  return (
    <div className="mt-8">
      <h3 className="text-lg font-medium text-gray-700 mb-3">Historial de búsquedas</h3>
      <div className="flex flex-wrap gap-2">
        {history.map((item, index) => (
          <button
            key={index}
            onClick={() => onSelect(item)}
            className="px-3 py-1 bg-gray-100 rounded-full text-sm text-gray-700 hover:bg-gray-200 transition-colors"
          >
            {item}
          </button>
        ))}
      </div>
    </div>
  );
};

export default WikiHistory;